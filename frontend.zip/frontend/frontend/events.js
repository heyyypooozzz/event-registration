// js/events.js (Conceptual example)

async function loadAllEvents() {
    const eventsListDiv = document.getElementById('eventsList');
    const errorMessageDiv = document.getElementById('errorMessage');
    errorMessageDiv.style.display = 'none'; // Hide error initially

    // Clear existing content and show loading message (if not already present from HTML)
    eventsListDiv.innerHTML = '<p class="loading-message">Loading events...</p>'; 

    try {
        // Replace with your actual API call. 'api' is assumed to be defined in api.js
        const response = await api.get('/events'); 
        const events = response.data; // Assuming your API returns an array of event objects

        if (events && events.length > 0) {
            eventsListDiv.innerHTML = ''; // Clear the loading message/static placeholders

            events.forEach(event => {
                const eventCard = document.createElement('div');
                eventCard.classList.add('event-card');
                
                // Use moment.js for date formatting if event.date is a valid date string
                const formattedMonth = moment(event.date).format('MMM').toUpperCase();
                const formattedDay = moment(event.date).format('DD');

                eventCard.innerHTML = `
                    <div class="event-image-wrapper">
                        <img src="${event.imageUrl || 'https://via.placeholder.com/400x250/007bff/FFFFFF?text=Event'}" 
                             alt="${event.title}" class="event-image">
                        <span class="event-date">${formattedMonth} <br> ${formattedDay}</span>
                    </div>
                    <div class="event-info">
                        <h3>${event.title}</h3>
                        <p class="event-description">${event.description || 'No description available.'}</p>
                        <p class="event-location"><i class="fas fa-map-marker-alt"></i> ${event.location}</p>
                        <button class="view-details-btn" onclick="window.location.href='/event-details.html?id=${event.id}'">View Details</button>
                    </div>
                `;
                eventsListDiv.appendChild(eventCard);
            });
        } else {
            eventsListDiv.innerHTML = '<p class="loading-message">No upcoming events found.</p>';
        }

    } catch (error) {
        console.error('Error loading events:', error);
        eventsListDiv.innerHTML = ''; // Clear loading message/cards
        errorMessageDiv.textContent = 'Failed to load events. Please try again later.';
        errorMessageDiv.style.display = 'block';
    }
}

// Ensure this is called when the page loads, uncomment in index.html after testing CSS
// document.addEventListener('DOMContentLoaded', loadAllEvents);