// frontend-static/js/api.js

const API = axios.create({
    baseURL: 'http://localhost:5000/api', // Your backend API base URL
});

// Interceptor to attach token to requests
API.interceptors.request.use((config) => {
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    if (userInfo && userInfo.token) {
        config.headers.Authorization = `Bearer ${userInfo.token}`;
    }
    return config;
}, (error) => {
    return Promise.reject(error);
});