// frontend-static/js/auth.js

function setupLoginForm() {
    const loginForm = document.getElementById('loginForm');
    if (!loginForm) return;

    // If user is already logged in, redirect them from login page
    if (getUserInfo()) {
        window.location.href = '/';
        return;
    }

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        hideMessage('loginErrorMessage');

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        try {
            const response = await API.post('/auth/login', { email, password });
            localStorage.setItem('userInfo', JSON.stringify(response.data));
            window.location.href = '/'; // Redirect to home page
        } catch (error) {
            const message = error.response?.data?.message || 'Login failed';
            showMessage('loginErrorMessage', message);
        }
    });
}

function setupRegisterForm() {
    const registerForm = document.getElementById('registerForm');
    if (!registerForm) return;

    // If user is already logged in, redirect them from register page
    if (getUserInfo()) {
        window.location.href = '/';
        return;
    }

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        hideMessage('registerErrorMessage');

        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (password !== confirmPassword) {
            showMessage('registerErrorMessage', 'Passwords do not match');
            return;
        }

        try {
            const response = await API.post('/auth/register', { username, email, password });
            localStorage.setItem('userInfo', JSON.stringify(response.data));
            window.location.href = '/'; // Redirect to home page
        } catch (error) {
            const message = error.response?.data?.message || 'Registration failed';
            showMessage('registerErrorMessage', message);
        }
    });
}