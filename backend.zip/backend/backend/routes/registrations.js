// backend/routes/registrations.js
const express = require('express');
const {
    registerForEvent,
    getAttendeesForEvent,
    getMyRegistrations,
    unregisterFromEvent,
} = require('../controllers/registrationController');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/:eventId', protect, registerForEvent); // Register for an event
router.get('/myregistrations', protect, getMyRegistrations); // Get events user is registered for
router.get('/:eventId/attendees', protect, getAttendeesForEvent); // Get attendees for a specific event
router.delete('/:eventId', protect, unregisterFromEvent); // Unregister from an event

module.exports = router;
