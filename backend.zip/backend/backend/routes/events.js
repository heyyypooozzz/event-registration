// backend/routes/events.js
const express = require('express');
const {
    createEvent,
    getEvents,
    getEventById,
    updateEvent,
    deleteEvent,
    getMyEvents,
} = require('../controllers/eventController');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

router.route('/')
    .post(protect, createEvent) // Create event (protected)
    .get(getEvents);           // Get all events (public, with filters)

router.get('/myevents', protect, getMyEvents); // Get events created by logged-in user

router.route('/:id')
    .get(getEventById)     // Get single event (public)
    .put(protect, updateEvent)  // Update event (protected, creator only)
    .delete(protect, deleteEvent); // Delete event (protected, creator only)

module.exports = router;