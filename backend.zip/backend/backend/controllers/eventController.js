// backend/controllers/eventController.js
const Event = require('../models/Event');
const User = require('../models/User'); // Assuming you might need user info

// @desc    Create a new event
// @route   POST /api/events
// @access  Private
const createEvent = async (req, res) => {
    const { title, description, date, location, category } = req.body;

    if (!title || !description || !date || !location) {
        return res.status(400).json({ message: 'Please fill all required fields' });
    }

    try {
        const event = await Event.create({
            title,
            description,
            date,
            location,
            category,
            creator: req.user.id, // Comes from the protect middleware
        });
        res.status(201).json(event);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error during event creation' });
    }
};

// @desc    Get all events
// @route   GET /api/events
// @access  Public
const getEvents = async (req, res) => {
    try {
        // Implement search/filter logic
        const { date, category, location, search } = req.query;
        let query = {};

        if (date) {
            // Basic date filtering (e.g., events on a specific day)
            // You might need more complex date range filtering depending on requirements
            const startOfDay = new Date(date);
            startOfDay.setUTCHours(0, 0, 0, 0);
            const endOfDay = new Date(date);
            endOfDay.setUTCHours(23, 59, 59, 999);
            query.date = { $gte: startOfDay, $lte: endOfDay };
        }
        if (category) {
            query.category = category;
        }
        if (location) {
            query.location = { $regex: location, $options: 'i' }; // Case-insensitive search
        }
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { description: { $regex: search, $options: 'i' } },
            ];
        }

        const events = await Event.find(query).sort({ date: 1 }).populate('creator', 'username email');
        res.status(200).json(events);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error fetching events' });
    }
};

// @desc    Get a single event by ID
// @route   GET /api/events/:id
// @access  Public
const getEventById = async (req, res) => {
    try {
        const event = await Event.findById(req.params.id).populate('creator', 'username email');
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }
        res.status(200).json(event);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error fetching event' });
    }
};

// @desc    Update an event
// @route   PUT /api/events/:id
// @access  Private (only creator can update)
const updateEvent = async (req, res) => {
    try {
        let event = await Event.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }

        // Check if the logged-in user is the event creator
        if (event.creator.toString() !== req.user.id) {
            return res.status(403).json({ message: 'Not authorized to update this event' });
        }

        event = await Event.findByIdAndUpdate(req.params.id, req.body, {
            new: true, // Return the updated document
            runValidators: true, // Run schema validators
        });

        res.status(200).json(event);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error updating event' });
    }
};

// @desc    Delete an event
// @route   DELETE /api/events/:id
// @access  Private (only creator can delete)
const deleteEvent = async (req, res) => {
    try {
        const event = await Event.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }

        // Check if the logged-in user is the event creator
        if (event.creator.toString() !== req.user.id) {
            return res.status(403).json({ message: 'Not authorized to delete this event' });
        }

        await Event.deleteOne({ _id: req.params.id }); // Use deleteOne or findByIdAndDelete
        res.status(200).json({ message: 'Event removed' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error deleting event' });
    }
};

// @desc    Get events created by the logged-in user
// @route   GET /api/events/myevents
// @access  Private
const getMyEvents = async (req, res) => {
    try {
        const myEvents = await Event.find({ creator: req.user.id }).sort({ date: 1 });
        res.status(200).json(myEvents);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error fetching user events' });
    }
};


module.exports = {
    createEvent,
    getEvents,
    getEventById,
    updateEvent,
    deleteEvent,
    getMyEvents,
};