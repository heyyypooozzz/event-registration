// backend/controllers/registrationController.js
const Registration = require('../models/Registration');
const Event = require('../models/Event');
const User = require('../models/User');

// @desc    Register a user for an event
// @route   POST /api/registrations/:eventId
// @access  Private
const registerForEvent = async (req, res) => {
    const { eventId } = req.params;
    const userId = req.user.id; // From auth middleware

    try {
        const event = await Event.findById(eventId);
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }

        // Check if already registered
        const existingRegistration = await Registration.findOne({ event: eventId, user: userId });
        if (existingRegistration) {
            return res.status(400).json({ message: 'Already registered for this event' });
        }

        const registration = await Registration.create({
            event: eventId,
            user: userId,
        });

        res.status(201).json(registration);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error during registration' });
    }
};

// @desc    Get registrations for a specific event (for event creators)
// @route   GET /api/registrations/:eventId/attendees
// @access  Private (only event creator can view)
const getAttendeesForEvent = async (req, res) => {
    const { eventId } = req.params;
    const userId = req.user.id;

    try {
        const event = await Event.findById(eventId);
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }

        // Ensure the logged-in user is the creator of the event
        if (event.creator.toString() !== userId) {
            return res.status(403).json({ message: 'Not authorized to view attendees for this event' });
        }

        const attendees = await Registration.find({ event: eventId }).populate('user', 'username email');
        res.status(200).json(attendees);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error fetching attendees' });
    }
};

// @desc    Get events a user is registered for
// @route   GET /api/registrations/myregistrations
// @access  Private
const getMyRegistrations = async (req, res) => {
    const userId = req.user.id;

    try {
        const registrations = await Registration.find({ user: userId }).populate('event');
        res.status(200).json(registrations);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error fetching user registrations' });
    }
};

// @desc    Unregister a user from an event
// @route   DELETE /api/registrations/:eventId
// @access  Private
const unregisterFromEvent = async (req, res) => {
    const { eventId } = req.params;
    const userId = req.user.id;

    try {
        const registration = await Registration.findOneAndDelete({ event: eventId, user: userId });

        if (!registration) {
            return res.status(404).json({ message: 'Registration not found' });
        }

        res.status(200).json({ message: 'Successfully unregistered from event' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error during unregistration' });
    }
};

module.exports = {
    registerForEvent,
    getAttendeesForEvent,
    getMyRegistrations,
    unregisterFromEvent,
};